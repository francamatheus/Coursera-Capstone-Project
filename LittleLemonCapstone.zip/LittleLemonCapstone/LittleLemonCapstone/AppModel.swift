import Combine
import Foundation

enum AvatarMode: String, Equatable {
    case asset
    case initials
    case custom
}

struct ProfileDraft: Equatable {
    var firstName: String = ""
    var lastName: String = ""
    var email: String = ""
    var phone: String = ""
    var orderStatuses: Bool = true
    var passwordChanges: Bool = false
    var specialOffers: Bool = true
    var newsletter: Bool = false
    var avatarMode: AvatarMode = .asset
    var avatarJPEG: Data? = nil

    var displayName: String {
        let name = "\(FieldValidation.trimmed(firstName)) \(FieldValidation.trimmed(lastName))"
            .trimmingCharacters(in: .whitespacesAndNewlines)
        return name.isEmpty ? "Guest" : name
    }

    var initials: String {
        let first = FieldValidation.trimmed(firstName).first.map(String.init) ?? ""
        let last = FieldValidation.trimmed(lastName).first.map(String.init) ?? ""
        let letters = (first + last).uppercased()
        return letters.isEmpty ? "LL" : letters
    }

    var detailsAreValid: Bool {
        FieldValidation.isNonEmpty(firstName)
            && FieldValidation.isNonEmpty(lastName)
            && FieldValidation.isValidEmail(email)
    }

    var isValid: Bool {
        detailsAreValid && FieldValidation.isValidPhone(phone)
    }
}

enum FieldValidation {
    static func trimmed(_ value: String) -> String {
        value.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    static func isNonEmpty(_ value: String) -> Bool {
        !trimmed(value).isEmpty
    }

    static func isValidEmail(_ value: String) -> Bool {
        let email = trimmed(value)
        let pattern = #"^[A-Z0-9a-z._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,64}$"#
        return email.range(of: pattern, options: .regularExpression) != nil
    }

    static func isValidPhone(_ value: String) -> Bool {
        let phone = trimmed(value)
        if phone.isEmpty {
            return true
        }
        let allowed = CharacterSet(charactersIn: "0123456789+ -()")
        let scalarsAreAllowed = phone.unicodeScalars.allSatisfy { allowed.contains($0) }
        let digits = phone.filter(\.isNumber).count
        return scalarsAreAllowed && digits >= 7 && digits <= 15
    }
}

final class AppModel: ObservableObject {
    static let offlineMessage = "You're offline or the menu couldn't be loaded. Showing the saved Little Lemon menu."

    private let defaults: UserDefaults
    private var didStartInitialLoad = false

    @Published var isLoggedIn: Bool
    @Published var firstName: String
    @Published var lastName: String
    @Published var email: String
    @Published var phone: String
    @Published var orderStatuses: Bool
    @Published var passwordChanges: Bool
    @Published var specialOffers: Bool
    @Published var newsletter: Bool
    @Published var avatarMode: AvatarMode
    @Published var avatarJPEG: Data?

    @Published var searchText = ""
    @Published var selectedCategory: MenuCategory?

    @Published var menu: [MenuItem]
    @Published var isLoading: Bool
    @Published var loadError: String?

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        isLoggedIn = defaults.bool(forKey: Keys.isLoggedIn)
        firstName = defaults.string(forKey: Keys.firstName) ?? ""
        lastName = defaults.string(forKey: Keys.lastName) ?? ""
        email = defaults.string(forKey: Keys.email) ?? ""
        phone = defaults.string(forKey: Keys.phone) ?? ""
        orderStatuses = defaults.object(forKey: Keys.orderStatuses) as? Bool ?? true
        passwordChanges = defaults.object(forKey: Keys.passwordChanges) as? Bool ?? false
        specialOffers = defaults.object(forKey: Keys.specialOffers) as? Bool ?? true
        newsletter = defaults.object(forKey: Keys.newsletter) as? Bool ?? false
        avatarMode = AvatarMode(rawValue: defaults.string(forKey: Keys.avatarMode) ?? "") ?? .asset
        avatarJPEG = defaults.data(forKey: Keys.avatarJPEG)
        menu = []
        isLoading = true
        loadError = nil
    }

    var profileDraft: ProfileDraft {
        ProfileDraft(
            firstName: firstName,
            lastName: lastName,
            email: email,
            phone: phone,
            orderStatuses: orderStatuses,
            passwordChanges: passwordChanges,
            specialOffers: specialOffers,
            newsletter: newsletter,
            avatarMode: avatarMode,
            avatarJPEG: avatarJPEG
        )
    }

    var fullName: String {
        profileDraft.displayName
    }

    var initials: String {
        profileDraft.initials
    }

    var filteredMenu: [MenuItem] {
        let query = FieldValidation.trimmed(searchText)
        return menu.filter { item in
            let categoryMatches = selectedCategory.map { item.category == $0.rawValue } ?? true
            guard categoryMatches else { return false }
            guard !query.isEmpty else { return true }
            return item.title.localizedCaseInsensitiveContains(query)
                || item.description.localizedCaseInsensitiveContains(query)
                || item.category.localizedCaseInsensitiveContains(query)
        }
    }

    func toggleCategory(_ category: MenuCategory) {
        if selectedCategory == category {
            selectedCategory = nil
        } else {
            selectedCategory = category
        }
    }

    func register(_ draft: ProfileDraft) {
        apply(draft)
        isLoggedIn = true
        persist()
    }

    func saveProfile(_ draft: ProfileDraft) {
        apply(draft)
        persist()
    }

    func logOut() {
        firstName = ""
        lastName = ""
        email = ""
        phone = ""
        orderStatuses = true
        passwordChanges = false
        specialOffers = true
        newsletter = false
        avatarMode = .asset
        avatarJPEG = nil
        searchText = ""
        selectedCategory = nil
        isLoggedIn = false
        Keys.all.forEach { defaults.removeObject(forKey: $0) }
    }

    func loadMenuIfNeeded() async {
        let shouldStart: Bool = await MainActor.run {
            if didStartInitialLoad {
                return false
            }
            didStartInitialLoad = true
            isLoading = true
            return true
        }
        guard shouldStart else { return }
        await performFetch()
    }

    func retryMenu() async {
        await MainActor.run {
            isLoading = true
            loadError = nil
        }
        await performFetch()
    }

    private func performFetch() async {
        do {
            var request = URLRequest(url: MenuService.endpoint)
            request.timeoutInterval = 20
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
                throw URLError(.badServerResponse)
            }
            let decoded = try JSONDecoder().decode(MenuResponse.self, from: data)
            guard !decoded.menu.isEmpty else {
                throw URLError(.cannotParseResponse)
            }
            let items = SampleMenu.mergingDrinks(into: decoded.menu)
            await MainActor.run {
                menu = items
                loadError = nil
                isLoading = false
            }
        } catch {
            await MainActor.run {
                menu = SampleMenu.items
                loadError = Self.offlineMessage
                isLoading = false
            }
        }
    }

    private func apply(_ draft: ProfileDraft) {
        firstName = FieldValidation.trimmed(draft.firstName)
        lastName = FieldValidation.trimmed(draft.lastName)
        email = FieldValidation.trimmed(draft.email)
        phone = FieldValidation.trimmed(draft.phone)
        orderStatuses = draft.orderStatuses
        passwordChanges = draft.passwordChanges
        specialOffers = draft.specialOffers
        newsletter = draft.newsletter
        if draft.avatarMode == .custom, let jpeg = draft.avatarJPEG {
            avatarMode = .custom
            avatarJPEG = jpeg
        } else if draft.avatarMode == .initials {
            avatarMode = .initials
            avatarJPEG = nil
        } else {
            avatarMode = .asset
            avatarJPEG = nil
        }
    }

    private func persist() {
        defaults.set(isLoggedIn, forKey: Keys.isLoggedIn)
        defaults.set(firstName, forKey: Keys.firstName)
        defaults.set(lastName, forKey: Keys.lastName)
        defaults.set(email, forKey: Keys.email)
        defaults.set(phone, forKey: Keys.phone)
        defaults.set(orderStatuses, forKey: Keys.orderStatuses)
        defaults.set(passwordChanges, forKey: Keys.passwordChanges)
        defaults.set(specialOffers, forKey: Keys.specialOffers)
        defaults.set(newsletter, forKey: Keys.newsletter)
        defaults.set(avatarMode.rawValue, forKey: Keys.avatarMode)
        if let avatarJPEG {
            defaults.set(avatarJPEG, forKey: Keys.avatarJPEG)
        } else {
            defaults.removeObject(forKey: Keys.avatarJPEG)
        }
    }

    private func seedPreviewContent() {
        firstName = "Ada"
        lastName = "Lemon"
        email = "ada@littlelemon.com"
        phone = "3125550148"
        orderStatuses = true
        passwordChanges = false
        specialOffers = true
        newsletter = true
        avatarMode = .asset
        avatarJPEG = nil
        isLoggedIn = true
        menu = SampleMenu.items
        isLoading = false
        loadError = nil
        didStartInitialLoad = true
        persist()
    }

    static let preview: AppModel = makePreview(loggedIn: true)
    static let previewLoggedOut: AppModel = makePreview(loggedIn: false)

    private static func makePreview(loggedIn: Bool) -> AppModel {
        let name = loggedIn
            ? "com.littlelemon.capstone.preview"
            : "com.littlelemon.capstone.preview.loggedout"
        let defaults = UserDefaults(suiteName: name) ?? .standard
        if defaults !== UserDefaults.standard {
            defaults.removePersistentDomain(forName: name)
        }
        let model = AppModel(defaults: defaults)
        if loggedIn {
            model.seedPreviewContent()
        } else {
            model.isLoading = false
        }
        return model
    }

    private enum Keys {
        static let isLoggedIn = "littlelemon.isLoggedIn"
        static let firstName = "littlelemon.firstName"
        static let lastName = "littlelemon.lastName"
        static let email = "littlelemon.email"
        static let phone = "littlelemon.phone"
        static let orderStatuses = "littlelemon.orderStatuses"
        static let passwordChanges = "littlelemon.passwordChanges"
        static let specialOffers = "littlelemon.specialOffers"
        static let newsletter = "littlelemon.newsletter"
        static let avatarMode = "littlelemon.avatarMode"
        static let avatarJPEG = "littlelemon.avatarJPEG"

        static let all = [
            isLoggedIn,
            firstName,
            lastName,
            email,
            phone,
            orderStatuses,
            passwordChanges,
            specialOffers,
            newsletter,
            avatarMode,
            avatarJPEG
        ]
    }
}
