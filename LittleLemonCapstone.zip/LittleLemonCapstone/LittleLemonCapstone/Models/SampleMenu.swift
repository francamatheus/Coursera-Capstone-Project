import Foundation

enum SampleMenu {
    private static let imageBase = "https://github.com/Meta-Mobile-Developer-PC/Working-With-Data-API/blob/main/images/"

    static let drinks: [MenuItem] = [
        MenuItem(
            id: 101,
            title: "Lemonade",
            description: "House-squeezed lemons, a little sugar, and a sprig of mint.",
            price: "4",
            image: "",
            category: MenuCategory.drinks.rawValue
        ),
        MenuItem(
            id: 102,
            title: "Sparkling Water",
            description: "Cold sparkling water with a fresh lemon slice.",
            price: "3",
            image: "",
            category: MenuCategory.drinks.rawValue
        )
    ]

    /// Offline copy of the public Little Lemon menu, plus house drinks so every category has rows.
    static let items: [MenuItem] = [
        MenuItem(
            id: 1,
            title: "Greek Salad",
            description: "The famous greek salad of crispy lettuce, peppers, olives, our Chicago.",
            price: "10",
            image: imageBase + "greekSalad.jpg?raw=true",
            category: "starters"
        ),
        MenuItem(
            id: 5,
            title: "Bruschetta",
            description: "Oven-baked bruschetta stuffed with tomatos and herbs.",
            price: "10",
            image: imageBase + "bruschetta.jpg?raw=true",
            category: "starters"
        ),
        MenuItem(
            id: 3,
            title: "Grilled Fish",
            description: "Our Bruschetta is made from grilled bread that has been smeared with garlic and seasoned with salt and olive oil.",
            price: "10",
            image: imageBase + "grilledFish.jpg?raw=true",
            category: "mains"
        ),
        MenuItem(
            id: 4,
            title: "Pasta",
            description: "Penne with fried aubergines, cherry tomatoes, tomato sauce, fresh chilli, garlic, basil & salted ricotta cheese.",
            price: "10",
            image: imageBase + "pasta.jpg?raw=true",
            category: "mains"
        ),
        MenuItem(
            id: 2,
            title: "Lemon Desert",
            description: "Traditional homemade Italian Lemon Ricotta Cake.",
            price: "10",
            image: imageBase + "lemonDessert%202.jpg?raw=true",
            category: "desserts"
        )
    ] + drinks

    static func mergingDrinks(into remote: [MenuItem]) -> [MenuItem] {
        let hasDrinks = remote.contains { $0.category == MenuCategory.drinks.rawValue }
        if hasDrinks {
            return remote
        }
        let remoteTitles = Set(remote.map { $0.title.lowercased() })
        let extraDrinks = drinks.filter { !remoteTitles.contains($0.title.lowercased()) }
        return remote + extraDrinks
    }
}
