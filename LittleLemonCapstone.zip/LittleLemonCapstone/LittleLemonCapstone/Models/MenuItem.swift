import Foundation

enum MenuCategory: String, CaseIterable, Identifiable {
    case starters
    case mains
    case desserts
    case drinks

    var id: String { rawValue }

    var title: String {
        switch self {
        case .starters:
            return "Starters"
        case .mains:
            return "Mains"
        case .desserts:
            return "Desserts"
        case .drinks:
            return "Drinks"
        }
    }
}

enum MenuService {
    static let endpoint = URL(
        string: "https://raw.githubusercontent.com/Meta-Mobile-Developer-PC/Working-With-Data-API/main/menu.json"
    )!
}

struct MenuResponse: Decodable {
    let menu: [MenuItem]
}

struct MenuItem: Identifiable, Decodable {
    let sourceID: Int
    let title: String
    let description: String
    let price: String
    let image: String
    let category: String

    var id: String { "\(sourceID)|\(title)" }

    init(id: Int, title: String, description: String, price: String, image: String, category: String) {
        self.sourceID = id
        self.title = title
        self.description = description
        self.price = price
        self.image = image
        self.category = category
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .lowercased()
    }

    enum CodingKeys: String, CodingKey {
        case id
        case title
        case description
        case price
        case image
        case category
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        let sourceID = try container.decode(Int.self, forKey: .id)
        let title = try container.decode(String.self, forKey: .title)
        let description = try container.decode(String.self, forKey: .description)
        let image = try container.decode(String.self, forKey: .image)
        let category = try container.decode(String.self, forKey: .category)
        let price = try Self.decodePrice(from: container)
        self.init(
            id: sourceID,
            title: title,
            description: description,
            price: price,
            image: image,
            category: category
        )
    }

    private static func decodePrice(from container: KeyedDecodingContainer<CodingKeys>) throws -> String {
        if let stringPrice = try? container.decode(String.self, forKey: .price) {
            return stringPrice
        }
        if let doublePrice = try? container.decode(Double.self, forKey: .price) {
            return String(doublePrice)
        }
        if let intPrice = try? container.decode(Int.self, forKey: .price) {
            return String(intPrice)
        }
        return ""
    }

    var priceDisplay: String {
        let cleaned = price
            .replacingOccurrences(of: "$", with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        if let number = Double(cleaned),
           let formatted = Self.priceFormatter.string(from: NSNumber(value: number)) {
            return formatted
        }
        let trimmed = price.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.isEmpty {
            return "—"
        }
        return trimmed.hasPrefix("$") ? trimmed : "$\(trimmed)"
    }

    var fallbackImageName: String {
        switch category {
        case MenuCategory.starters.rawValue:
            return "MenuStarters"
        case MenuCategory.mains.rawValue:
            return "MenuMains"
        case MenuCategory.desserts.rawValue:
            return "MenuDesserts"
        case MenuCategory.drinks.rawValue:
            return "MenuDrinks"
        default:
            return "MenuMains"
        }
    }

    var remoteImageURL: URL? {
        guard let url = URL(string: image),
              let scheme = url.scheme?.lowercased(),
              scheme == "https" || scheme == "http" else {
            return nil
        }
        return url
    }

    private static let priceFormatter: NumberFormatter = {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.currencyCode = "USD"
        formatter.locale = Locale(identifier: "en_US")
        return formatter
    }()
}
