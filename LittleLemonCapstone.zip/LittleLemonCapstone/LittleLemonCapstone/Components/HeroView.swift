import SwiftUI

struct HeroView: View {
    @EnvironmentObject private var model: AppModel
    @FocusState private var searchFocused: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .top, spacing: 12) {
                VStack(alignment: .leading, spacing: 6) {
                    Text("Little Lemon")
                        .font(LittleLemonTheme.display(36, weight: .medium))
                        .foregroundColor(LittleLemonTheme.yellow)
                        .minimumScaleFactor(0.7)
                        .lineLimit(1)
                        .accessibilityAddTraits(.isHeader)
                    Text("Chicago")
                        .font(LittleLemonTheme.display(22, weight: .semibold))
                        .foregroundColor(.white)
                    Text("We are a family owned Mediterranean restaurant, focused on traditional recipes served with a modern twist.")
                        .font(LittleLemonTheme.body(14))
                        .foregroundColor(LittleLemonTheme.cloud)
                        .fixedSize(horizontal: false, vertical: true)
                }
                Image("HeroFood")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 112, height: 132)
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .accessibilityHidden(true)
            }

            HStack(spacing: 8) {
                Image(systemName: "magnifyingglass")
                    .foregroundColor(LittleLemonTheme.green)
                    .accessibilityHidden(true)
                TextField("Search menu", text: $model.searchText)
                    .focused($searchFocused)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled(true)
                    .submitLabel(.search)
                    .keyboardType(.webSearch)
                    .accessibilityLabel("Search menu")
                    .onSubmit { searchFocused = false }
                if !model.searchText.isEmpty {
                    Button {
                        model.searchText = ""
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundColor(LittleLemonTheme.muted)
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("Clear search")
                }
                Button {
                    searchFocused = true
                } label: {
                    Image(systemName: "magnifyingglass")
                        .font(.system(size: 16, weight: .bold))
                        .foregroundColor(LittleLemonTheme.charcoal)
                        .frame(width: 36, height: 36)
                        .background(LittleLemonTheme.yellow)
                        .clipShape(Circle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Search")
                .accessibilityHint("Moves the cursor to the search field")
            }
            .padding(.leading, 12)
            .padding(.trailing, 6)
            .padding(.vertical, 6)
            .background(Color.white)
            .clipShape(Capsule())
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(LittleLemonTheme.green)
        .accessibilityElement(children: .contain)
    }
}
