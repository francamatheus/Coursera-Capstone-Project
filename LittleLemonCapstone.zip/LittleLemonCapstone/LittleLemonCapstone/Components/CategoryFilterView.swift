import SwiftUI

struct CategoryFilterView: View {
    @EnvironmentObject private var model: AppModel

    private var dishCountLabel: String {
        let count = model.filteredMenu.count
        if model.isLoading && model.menu.isEmpty {
            return "Loading dishes"
        }
        return count == 1 ? "1 dish" : "\(count) dishes"
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .firstTextBaseline) {
                Text("ORDER FOR DELIVERY!")
                    .font(LittleLemonTheme.body(18, weight: .heavy))
                    .foregroundColor(LittleLemonTheme.charcoal)
                    .accessibilityAddTraits(.isHeader)
                    .accessibilityLabel("Menu breakdown. Order for delivery.")
                Spacer(minLength: 8)
                Image(systemName: "box.truck")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundColor(LittleLemonTheme.green)
                    .accessibilityHidden(true)
            }

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 10) {
                    ForEach(MenuCategory.allCases) { category in
                        categoryButton(category)
                    }
                }
                .padding(.vertical, 2)
            }

            Text(dishCountLabel)
                .font(LittleLemonTheme.body(13, weight: .semibold))
                .foregroundColor(LittleLemonTheme.muted)
                .accessibilityLabel(dishCountLabel)
        }
        .padding(.horizontal, 16)
        .padding(.top, 18)
        .padding(.bottom, 8)
    }

    private func categoryButton(_ category: MenuCategory) -> some View {
        let isSelected = model.selectedCategory == category
        return Button {
            model.toggleCategory(category)
        } label: {
            Text(category.title)
                .font(LittleLemonTheme.body(15, weight: .semibold))
                .foregroundColor(isSelected ? Color.white : LittleLemonTheme.green)
                .padding(.horizontal, 16)
                .padding(.vertical, 10)
                .background(isSelected ? LittleLemonTheme.green : LittleLemonTheme.cloud)
                .clipShape(Capsule())
                .overlay(
                    Capsule()
                        .stroke(LittleLemonTheme.green, lineWidth: 1)
                )
        }
        .buttonStyle(.plain)
        .accessibilityLabel(category.title)
        .accessibilityHint(
            isSelected
                ? "Selected. Activate to show the full menu."
                : "Filters the menu to \(category.title)."
        )
        .accessibilityAddTraits(isSelected ? .isSelected : [])
        .accessibilityIdentifier("category_\(category.rawValue)")
    }
}
