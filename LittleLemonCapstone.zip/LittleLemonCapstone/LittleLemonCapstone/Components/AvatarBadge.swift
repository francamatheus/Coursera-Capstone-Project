import SwiftUI
import UIKit

struct AvatarBadge: View {
    var mode: AvatarMode
    var jpeg: Data?
    var initials: String
    var size: CGFloat

    var body: some View {
        content
            .frame(width: size, height: size)
            .clipShape(Circle())
            .overlay(
                Circle()
                    .stroke(LittleLemonTheme.yellow, lineWidth: max(2, size / 22))
            )
    }

    @ViewBuilder
    private var content: some View {
        switch mode {
        case .initials:
            initialsFace
        case .custom:
            if let jpeg, let image = UIImage(data: jpeg) {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFill()
            } else {
                assetFace
            }
        case .asset:
            assetFace
        }
    }

    private var assetFace: some View {
        Image("ProfileAvatar")
            .resizable()
            .scaledToFill()
    }

    private var initialsFace: some View {
        ZStack {
            LittleLemonTheme.green
            Text(initials)
                .font(.system(size: size * 0.36, weight: .bold, design: .serif))
                .foregroundColor(LittleLemonTheme.yellow)
                .minimumScaleFactor(0.6)
                .lineLimit(1)
        }
    }
}

enum AvatarImageStore {
    static func jpegData(from data: Data) -> Data? {
        guard let image = UIImage(data: data) else { return nil }
        let maxSide: CGFloat = 512
        let largest = max(image.size.width, image.size.height)
        let rendered: UIImage
        if largest > maxSide, largest > 0 {
            let ratio = maxSide / largest
            let size = CGSize(width: image.size.width * ratio, height: image.size.height * ratio)
            let renderer = UIGraphicsImageRenderer(size: size)
            rendered = renderer.image { _ in
                image.draw(in: CGRect(origin: .zero, size: size))
            }
        } else {
            rendered = image
        }
        return rendered.jpegData(compressionQuality: 0.7)
    }
}
