import SwiftUI

struct MenuRowView: View {
    let item: MenuItem

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            VStack(alignment: .leading, spacing: 6) {
                Text(item.title)
                    .font(LittleLemonTheme.body(16, weight: .bold))
                    .foregroundColor(LittleLemonTheme.charcoal)
                    .fixedSize(horizontal: false, vertical: true)
                Text(item.description)
                    .font(LittleLemonTheme.body(14))
                    .foregroundColor(LittleLemonTheme.muted)
                    .lineLimit(2)
                    .fixedSize(horizontal: false, vertical: true)
                Text(item.priceDisplay)
                    .font(LittleLemonTheme.body(16, weight: .semibold))
                    .foregroundColor(LittleLemonTheme.green)
                    .padding(.top, 2)
            }
            Spacer(minLength: 8)
            thumbnail
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .accessibilityElement(children: .combine)
        .accessibilityLabel("\(item.title), \(item.priceDisplay). \(item.description)")
    }

    @ViewBuilder
    private var thumbnail: some View {
        Group {
            if let url = item.remoteImageURL {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .success(let image):
                        image.resizable().scaledToFill()
                    case .empty:
                        ZStack {
                            LittleLemonTheme.cloud
                            ProgressView()
                        }
                    default:
                        fallbackImage
                    }
                }
            } else {
                fallbackImage
            }
        }
        .frame(width: 76, height: 76)
        .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
        .accessibilityHidden(true)
    }

    private var fallbackImage: some View {
        Image(item.fallbackImageName)
            .resizable()
            .scaledToFill()
    }
}
