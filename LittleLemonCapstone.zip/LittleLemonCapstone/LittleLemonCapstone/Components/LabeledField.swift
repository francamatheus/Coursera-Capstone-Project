import SwiftUI
import UIKit

struct LabeledField: View {
    let title: String
    let placeholder: String
    @Binding var text: String
    var keyboard: UIKeyboardType = .default
    var contentType: UITextContentType?
    var capitalization: TextInputAutocapitalization = .words
    var disablesAutocorrection = false
    var submitLabel: SubmitLabel = .done
    var error: String?

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title)
                .font(LittleLemonTheme.body(13, weight: .semibold))
                .foregroundColor(LittleLemonTheme.charcoal)
            TextField(placeholder, text: $text)
                .keyboardType(keyboard)
                .textContentType(contentType)
                .textInputAutocapitalization(capitalization)
                .autocorrectionDisabled(disablesAutocorrection)
                .submitLabel(submitLabel)
                .padding(12)
                .background(Color.white)
                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 10, style: .continuous)
                        .stroke(error == nil ? LittleLemonTheme.border : Color.red, lineWidth: 1.5)
                )
                .accessibilityLabel(title)
            if let error {
                Text(error)
                    .font(LittleLemonTheme.body(12))
                    .foregroundColor(.red)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }
}
