import SwiftUI

struct PreferenceToggle: View {
    let title: String
    let detail: String
    @Binding var isOn: Bool

    var body: some View {
        Toggle(isOn: $isOn) {
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(LittleLemonTheme.body(16, weight: .semibold))
                    .foregroundColor(LittleLemonTheme.charcoal)
                Text(detail)
                    .font(LittleLemonTheme.body(13))
                    .foregroundColor(LittleLemonTheme.muted)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .tint(LittleLemonTheme.green)
        .padding(.vertical, 6)
        .accessibilityHint(detail)
    }
}
