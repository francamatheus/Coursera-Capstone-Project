import SwiftUI

struct HeaderView: View {
    @EnvironmentObject private var model: AppModel

    var body: some View {
        HStack(alignment: .center, spacing: 12) {
            Image("Logo")
                .resizable()
                .scaledToFit()
                .frame(height: 40)
                .accessibilityLabel("Little Lemon")

            Spacer(minLength: 8)

            NavigationLink {
                ProfileView()
            } label: {
                AvatarBadge(
                    mode: model.avatarMode,
                    jpeg: model.avatarJPEG,
                    initials: model.initials,
                    size: 46
                )
                .accessibilityHidden(true)
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Profile, \(model.fullName)")
            .accessibilityHint("Opens your profile")
            .accessibilityIdentifier("profileButton")
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
        .background(Color.white)
        .accessibilityElement(children: .contain)
    }
}
