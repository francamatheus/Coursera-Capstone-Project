import SwiftUI
import UIKit

enum LittleLemonTheme {
    static let green = Color(red: 73 / 255, green: 94 / 255, blue: 87 / 255)
    static let yellow = Color(red: 244 / 255, green: 206 / 255, blue: 20 / 255)
    static let orange = Color(red: 238 / 255, green: 153 / 255, blue: 114 / 255)
    static let peach = Color(red: 251 / 255, green: 218 / 255, blue: 187 / 255)
    static let cloud = Color(red: 237 / 255, green: 239 / 255, blue: 238 / 255)
    static let charcoal = Color(red: 51 / 255, green: 51 / 255, blue: 51 / 255)
    static let border = Color(red: 0.78, green: 0.80, blue: 0.79)
    static let muted = Color(red: 0.36, green: 0.38, blue: 0.37)

    static func display(_ size: CGFloat, weight: Font.Weight = .medium) -> Font {
        .system(size: size, weight: weight, design: .serif)
    }

    static func body(_ size: CGFloat, weight: Font.Weight = .regular) -> Font {
        .system(size: size, weight: weight, design: .default)
    }
}

struct PrimaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(LittleLemonTheme.body(17, weight: .bold))
            .foregroundColor(LittleLemonTheme.charcoal)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
            .background(LittleLemonTheme.yellow)
            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            .opacity(configuration.isPressed ? 0.82 : 1)
    }
}

struct SecondaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(LittleLemonTheme.body(17, weight: .semibold))
            .foregroundColor(LittleLemonTheme.green)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
            .background(
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .fill(Color.white)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .stroke(LittleLemonTheme.green, lineWidth: 1.5)
            )
            .opacity(configuration.isPressed ? 0.82 : 1)
    }
}

extension View {
    /// iOS 16 keeps the single-value `onChange`. iOS 17 deprecates it, so pick the
    /// closure that matches the system at runtime.
    @ViewBuilder
    func onChangeCompat<Value: Equatable>(
        of value: Value,
        perform action: @escaping (Value) -> Void
    ) -> some View {
        if #available(iOS 17.0, *) {
            self.onChange(of: value) { _, newValue in
                action(newValue)
            }
        } else {
            self.onChange(of: value, perform: action)
        }
    }

    func dismissKeyboardToolbar() -> some View {
        toolbar {
            ToolbarItemGroup(placement: .keyboard) {
                Spacer()
                Button("Done") {
                    UIApplication.shared.sendAction(
                        #selector(UIResponder.resignFirstResponder),
                        to: nil,
                        from: nil,
                        for: nil
                    )
                }
            }
        }
    }
}
