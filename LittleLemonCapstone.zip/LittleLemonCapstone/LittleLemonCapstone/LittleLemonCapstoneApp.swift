import SwiftUI

@main
struct LittleLemonCapstoneApp: App {
    @StateObject private var model = AppModel()

    var body: some Scene {
        WindowGroup {
            Group {
                if model.isLoggedIn {
                    HomeView()
                } else {
                    OnboardingView()
                }
            }
            .environmentObject(model)
            .tint(LittleLemonTheme.green)
        }
    }
}
