import SwiftUI

struct OnboardingView: View {
    @EnvironmentObject private var model: AppModel
    @State private var page = 0
    @State private var firstName = ""
    @State private var lastName = ""
    @State private var email = ""
    @State private var phone = ""
    @State private var orderStatuses = true
    @State private var passwordChanges = false
    @State private var specialOffers = true
    @State private var newsletter = false
    @State private var showDetailErrors = false
    @State private var showPhoneErrors = false

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                TabView(selection: $page) {
                    welcomePage.tag(0)
                    detailsPage.tag(1)
                    confirmPage.tag(2)
                }
                .tabViewStyle(.page(indexDisplayMode: .never))
                .animation(.easeInOut(duration: 0.25), value: page)

                controls
            }
            .background(LittleLemonTheme.cloud.ignoresSafeArea())
            .toolbar(.hidden, for: .navigationBar)
            .dismissKeyboardToolbar()
            .onChangeCompat(of: page) { newPage in
                if newPage > 1 && !detailsAreValid {
                    page = 1
                    showDetailErrors = true
                }
            }
        }
        .tint(LittleLemonTheme.green)
    }

    private var detailsAreValid: Bool {
        FieldValidation.isNonEmpty(firstName)
            && FieldValidation.isNonEmpty(lastName)
            && FieldValidation.isValidEmail(email)
    }

    private var phoneIsValid: Bool {
        FieldValidation.isValidPhone(phone)
    }

    private var controls: some View {
        VStack(spacing: 12) {
            HStack(spacing: 8) {
                ForEach(0..<3, id: \.self) { index in
                    Capsule()
                        .fill(index == page ? LittleLemonTheme.green : Color.white)
                        .frame(width: index == page ? 22 : 8, height: 8)
                        .overlay(
                            Capsule().stroke(LittleLemonTheme.green.opacity(0.4), lineWidth: 1)
                        )
                }
            }
            .accessibilityElement(children: .ignore)
            .accessibilityLabel("Page \(page + 1) of 3")

            HStack(spacing: 12) {
                if page > 0 {
                    Button("Previous") {
                        withAnimation { page -= 1 }
                    }
                    .buttonStyle(SecondaryButtonStyle())
                    .accessibilityIdentifier("onboardingPrevious")
                }
                Button(page == 2 ? "Register" : "Next") {
                    advance()
                }
                .buttonStyle(PrimaryButtonStyle())
                .opacity(primaryEnabled ? 1 : 0.45)
                .accessibilityIdentifier(page == 2 ? "registerButton" : "onboardingNext")
            }
        }
        .padding(.horizontal, 20)
        .padding(.top, 8)
        .padding(.bottom, 16)
        .background(LittleLemonTheme.cloud)
    }

    private var primaryEnabled: Bool {
        if page == 1 { return detailsAreValid }
        if page == 2 { return detailsAreValid && phoneIsValid }
        return true
    }

    private func advance() {
        if page == 0 {
            withAnimation { page = 1 }
            return
        }
        if page == 1 {
            showDetailErrors = true
            guard detailsAreValid else { return }
            withAnimation { page = 2 }
            return
        }
        showPhoneErrors = true
        showDetailErrors = true
        guard detailsAreValid else {
            withAnimation { page = 1 }
            return
        }
        guard phoneIsValid else { return }
        model.register(
            ProfileDraft(
                firstName: firstName,
                lastName: lastName,
                email: email,
                phone: phone,
                orderStatuses: orderStatuses,
                passwordChanges: passwordChanges,
                specialOffers: specialOffers,
                newsletter: newsletter
            )
        )
    }

    private var welcomePage: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Image("Logo")
                    .resizable()
                    .scaledToFit()
                    .frame(height: 36)
                    .accessibilityLabel("Little Lemon")

                Text("Welcome")
                    .font(LittleLemonTheme.display(18, weight: .semibold))
                    .foregroundColor(LittleLemonTheme.green)

                VStack(alignment: .leading, spacing: 10) {
                    Text("Little Lemon")
                        .font(LittleLemonTheme.display(40, weight: .medium))
                        .foregroundColor(LittleLemonTheme.yellow)
                    Text("Chicago")
                        .font(LittleLemonTheme.display(24, weight: .semibold))
                        .foregroundColor(.white)
                    Text("A family table for Mediterranean food, delivered from our Chicago kitchen.")
                        .font(LittleLemonTheme.body(15))
                        .foregroundColor(LittleLemonTheme.cloud)
                        .fixedSize(horizontal: false, vertical: true)
                    Image("HeroFood")
                        .resizable()
                        .scaledToFill()
                        .frame(maxWidth: .infinity)
                        .frame(height: 170)
                        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                        .accessibilityLabel("Seasonal Little Lemon dish")
                }
                .padding(18)
                .background(LittleLemonTheme.green)
                .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))

                VStack(alignment: .leading, spacing: 12) {
                    welcomePoint(
                        symbol: "bicycle",
                        title: "Order for delivery",
                        detail: "Browse starters, mains, desserts, and drinks."
                    )
                    welcomePoint(
                        symbol: "person.crop.circle",
                        title: "Keep a profile",
                        detail: "Your name and email stay on this phone."
                    )
                    welcomePoint(
                        symbol: "bell",
                        title: "Choose updates",
                        detail: "Turn notices on or off before you register."
                    )
                }
            }
            .padding(20)
        }
        .scrollDismissesKeyboard(.interactively)
    }

    private func welcomePoint(symbol: String, title: String, detail: String) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: symbol)
                .font(.system(size: 16, weight: .semibold))
                .foregroundColor(LittleLemonTheme.green)
                .frame(width: 36, height: 36)
                .background(Color.white)
                .clipShape(Circle())
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(LittleLemonTheme.body(16, weight: .semibold))
                    .foregroundColor(LittleLemonTheme.charcoal)
                Text(detail)
                    .font(LittleLemonTheme.body(14))
                    .foregroundColor(LittleLemonTheme.muted)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .accessibilityElement(children: .combine)
    }

    private var detailsPage: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text("Your details")
                    .font(LittleLemonTheme.display(32, weight: .medium))
                    .foregroundColor(LittleLemonTheme.charcoal)
                    .accessibilityAddTraits(.isHeader)
                Text("We use this for your profile and order updates. All three fields are required.")
                    .font(LittleLemonTheme.body(15))
                    .foregroundColor(LittleLemonTheme.muted)
                    .fixedSize(horizontal: false, vertical: true)

                LabeledField(
                    title: "First name",
                    placeholder: "Ada",
                    text: $firstName,
                    contentType: .givenName,
                    submitLabel: .next,
                    error: showDetailErrors && !FieldValidation.isNonEmpty(firstName)
                        ? "Enter your first name."
                        : nil
                )
                LabeledField(
                    title: "Last name",
                    placeholder: "Lemon",
                    text: $lastName,
                    contentType: .familyName,
                    submitLabel: .next,
                    error: showDetailErrors && !FieldValidation.isNonEmpty(lastName)
                        ? "Enter your last name."
                        : nil
                )
                LabeledField(
                    title: "Email",
                    placeholder: "ada@littlelemon.com",
                    text: $email,
                    keyboard: .emailAddress,
                    contentType: .emailAddress,
                    capitalization: .never,
                    disablesAutocorrection: true,
                    submitLabel: .next,
                    error: emailError
                )
            }
            .padding(20)
        }
        .scrollDismissesKeyboard(.interactively)
    }

    private var emailError: String? {
        guard showDetailErrors else { return nil }
        if !FieldValidation.isNonEmpty(email) {
            return "Enter your email."
        }
        if !FieldValidation.isValidEmail(email) {
            return "Enter a valid email, such as ada@littlelemon.com."
        }
        return nil
    }

    private var confirmPage: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text("Confirm and register")
                    .font(LittleLemonTheme.display(32, weight: .medium))
                    .foregroundColor(LittleLemonTheme.charcoal)
                    .accessibilityAddTraits(.isHeader)
                Text("Check your details, add a phone if you want, and choose which notes to receive.")
                    .font(LittleLemonTheme.body(15))
                    .foregroundColor(LittleLemonTheme.muted)
                    .fixedSize(horizontal: false, vertical: true)

                VStack(alignment: .leading, spacing: 4) {
                    Text(displayName)
                        .font(LittleLemonTheme.display(26, weight: .medium))
                        .foregroundColor(LittleLemonTheme.yellow)
                    Text(FieldValidation.trimmed(email))
                        .font(LittleLemonTheme.body(15))
                        .foregroundColor(LittleLemonTheme.cloud)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(16)
                .background(LittleLemonTheme.green)
                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                .accessibilityElement(children: .combine)
                .accessibilityLabel("Registering \(displayName), \(FieldValidation.trimmed(email))")

                LabeledField(
                    title: "Phone number",
                    placeholder: "Optional",
                    text: $phone,
                    keyboard: .phonePad,
                    contentType: .telephoneNumber,
                    capitalization: .never,
                    disablesAutocorrection: true,
                    error: showPhoneErrors && !phoneIsValid
                        ? "Use at least 7 digits, or leave the phone blank."
                        : nil
                )

                Text("Email notifications")
                    .font(LittleLemonTheme.body(18, weight: .heavy))
                    .foregroundColor(LittleLemonTheme.charcoal)
                    .padding(.top, 4)
                    .accessibilityAddTraits(.isHeader)

                PreferenceToggle(
                    title: "Order statuses",
                    detail: "Get updates about your delivery.",
                    isOn: $orderStatuses
                )
                PreferenceToggle(
                    title: "Password changes",
                    detail: "Hear about password changes.",
                    isOn: $passwordChanges
                )
                PreferenceToggle(
                    title: "Special offers",
                    detail: "Receive deals and seasonal specials.",
                    isOn: $specialOffers
                )
                PreferenceToggle(
                    title: "Newsletter",
                    detail: "A few notes from the Little Lemon kitchen.",
                    isOn: $newsletter
                )

                Text("You can change these anytime in Profile.")
                    .font(LittleLemonTheme.body(13))
                    .foregroundColor(LittleLemonTheme.muted)
            }
            .padding(20)
        }
        .scrollDismissesKeyboard(.interactively)
    }

    private var displayName: String {
        let name = "\(FieldValidation.trimmed(firstName)) \(FieldValidation.trimmed(lastName))"
            .trimmingCharacters(in: .whitespacesAndNewlines)
        return name.isEmpty ? "Guest" : name
    }
}

struct OnboardingView_Previews: PreviewProvider {
    static var previews: some View {
        OnboardingView()
            .environmentObject(AppModel.previewLoggedOut)
    }
}
