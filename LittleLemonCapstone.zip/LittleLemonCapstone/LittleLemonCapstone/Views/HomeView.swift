import SwiftUI

struct HomeView: View {
    @EnvironmentObject private var model: AppModel

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                HeaderView()
                Divider()
                    .overlay(LittleLemonTheme.border)
                ScrollView {
                    VStack(alignment: .leading, spacing: 0) {
                        HeroView()
                        CategoryFilterView()
                        menuStatus
                        menuList
                    }
                }
                .scrollDismissesKeyboard(.interactively)
                .refreshable {
                    await model.retryMenu()
                }
            }
            .background(Color.white.ignoresSafeArea())
            // The bar is hidden here. Its title is what Profile shows on the system Back button.
            .navigationTitle("Back")
            .toolbar(.hidden, for: .navigationBar)
            .dismissKeyboardToolbar()
            .task {
                await model.loadMenuIfNeeded()
            }
        }
        .tint(LittleLemonTheme.green)
    }

    @ViewBuilder
    private var menuStatus: some View {
        if let message = model.loadError {
            VStack(alignment: .leading, spacing: 8) {
                Text(message)
                    .font(LittleLemonTheme.body(14))
                    .foregroundColor(LittleLemonTheme.charcoal)
                    .fixedSize(horizontal: false, vertical: true)
                Button("Try again") {
                    Task { await model.retryMenu() }
                }
                .font(LittleLemonTheme.body(14, weight: .bold))
                .foregroundColor(LittleLemonTheme.green)
                .accessibilityIdentifier("retryMenu")
            }
            .padding(12)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(LittleLemonTheme.peach)
            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            .padding(.horizontal, 16)
            .padding(.bottom, 8)
            .accessibilityElement(children: .combine)
        }
    }

    @ViewBuilder
    private var menuList: some View {
        if model.isLoading && model.menu.isEmpty {
            VStack(spacing: 12) {
                ProgressView()
                    .tint(LittleLemonTheme.green)
                Text("Loading the menu…")
                    .font(LittleLemonTheme.body(15))
                    .foregroundColor(LittleLemonTheme.muted)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 48)
            .accessibilityLabel("Loading the menu")
        } else if model.filteredMenu.isEmpty {
            VStack(spacing: 8) {
                Text("No dishes match")
                    .font(LittleLemonTheme.body(17, weight: .semibold))
                    .foregroundColor(LittleLemonTheme.charcoal)
                Text("Try another search or category.")
                    .font(LittleLemonTheme.body(14))
                    .foregroundColor(LittleLemonTheme.muted)
                Button("Show the full menu") {
                    model.searchText = ""
                    model.selectedCategory = nil
                }
                .font(LittleLemonTheme.body(15, weight: .bold))
                .foregroundColor(LittleLemonTheme.green)
                .padding(.top, 4)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 36)
            .padding(.horizontal, 16)
        } else {
            LazyVStack(spacing: 0) {
                ForEach(model.filteredMenu) { item in
                    MenuRowView(item: item)
                    Divider()
                        .overlay(LittleLemonTheme.cloud)
                        .padding(.leading, 16)
                }
            }
            .background(Color.white)
            .padding(.bottom, 24)
            .accessibilityIdentifier("foodMenuList")
        }
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
            .environmentObject(AppModel.preview)
    }
}
