import CoreTransferable
import PhotosUI
import SwiftUI
import UniformTypeIdentifiers

struct PickedImage: Transferable {
    let data: Data

    static var transferRepresentation: some TransferRepresentation {
        DataRepresentation(importedContentType: .image) { data in
            PickedImage(data: data)
        }
    }
}

struct ProfileView: View {
    @EnvironmentObject private var model: AppModel
    @State private var draft = ProfileDraft()
    @State private var loaded = false
    @State private var showErrors = false
    @State private var confirmLogout = false
    @State private var statusMessage = ""
    @State private var pickerItem: PhotosPickerItem?
    @State private var photoError = ""

    var body: some View {
        Group {
            if loaded {
                profileContent
            } else {
                ProgressView("Loading profile…")
                    .tint(LittleLemonTheme.green)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
        .background(LittleLemonTheme.cloud.ignoresSafeArea())
        .navigationTitle("Profile")
        .navigationBarTitleDisplayMode(.inline)
        .navigationBarBackButtonHidden(false)
        .dismissKeyboardToolbar()
        .onAppear {
            guard !loaded else { return }
            draft = model.profileDraft
            loaded = true
        }
        .onChangeCompat(of: pickerItem) { item in
            guard let item else { return }
            Task { await loadPhoto(item) }
        }
        .alert("Log out?", isPresented: $confirmLogout) {
            Button("Log out", role: .destructive) {
                model.logOut()
            }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("This clears your profile and returns to onboarding.")
        }
    }

    private var profileContent: some View {
        VStack(spacing: 0) {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    avatarControls
                    LabeledField(
                        title: "First name",
                        placeholder: "First name",
                        text: $draft.firstName,
                        contentType: .givenName,
                        submitLabel: .next,
                        error: showErrors && !FieldValidation.isNonEmpty(draft.firstName)
                            ? "Enter your first name."
                            : nil
                    )
                    LabeledField(
                        title: "Last name",
                        placeholder: "Last name",
                        text: $draft.lastName,
                        contentType: .familyName,
                        submitLabel: .next,
                        error: showErrors && !FieldValidation.isNonEmpty(draft.lastName)
                            ? "Enter your last name."
                            : nil
                    )
                    LabeledField(
                        title: "Email",
                        placeholder: "ada@littlelemon.com",
                        text: $draft.email,
                        keyboard: .emailAddress,
                        contentType: .emailAddress,
                        capitalization: .never,
                        disablesAutocorrection: true,
                        submitLabel: .next,
                        error: emailError
                    )
                    LabeledField(
                        title: "Phone number",
                        placeholder: "Optional",
                        text: $draft.phone,
                        keyboard: .phonePad,
                        contentType: .telephoneNumber,
                        capitalization: .never,
                        disablesAutocorrection: true,
                        error: showErrors && !FieldValidation.isValidPhone(draft.phone)
                            ? "Use at least 7 digits, or leave the phone blank."
                            : nil
                    )

                    Text("Email notifications")
                        .font(LittleLemonTheme.body(18, weight: .heavy))
                        .foregroundColor(LittleLemonTheme.charcoal)
                        .padding(.top, 4)
                        .accessibilityAddTraits(.isHeader)

                    PreferenceToggle(
                        title: "Order statuses",
                        detail: "Get updates about your delivery.",
                        isOn: $draft.orderStatuses
                    )
                    PreferenceToggle(
                        title: "Password changes",
                        detail: "Hear about password changes.",
                        isOn: $draft.passwordChanges
                    )
                    PreferenceToggle(
                        title: "Special offers",
                        detail: "Receive deals and seasonal specials.",
                        isOn: $draft.specialOffers
                    )
                    PreferenceToggle(
                        title: "Newsletter",
                        detail: "A few notes from the Little Lemon kitchen.",
                        isOn: $draft.newsletter
                    )
                }
                .padding(20)
            }
            .scrollDismissesKeyboard(.interactively)

            actionBar
        }
    }

    private var avatarControls: some View {
        VStack(spacing: 12) {
            AvatarBadge(
                mode: draft.avatarMode,
                jpeg: draft.avatarJPEG,
                initials: draft.initials,
                size: 96
            )
            .accessibilityLabel("Profile photo")
            .frame(maxWidth: .infinity)

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    photoPickerLabel
                    initialsButton
                    defaultPhotoButton
                }
            }

            if !photoError.isEmpty {
                Text(photoError)
                    .font(LittleLemonTheme.body(12))
                    .foregroundColor(.red)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
    }

    private var photoPickerLabel: some View {
        PhotosPicker(selection: $pickerItem, matching: .images) {
            avatarControlLabel("Change photo", systemImage: "photo")
        }
        .buttonStyle(.plain)
        .accessibilityHint("Choose a profile photo from your library")
    }

    private var initialsButton: some View {
        Button {
            draft.avatarMode = .initials
            photoError = ""
        } label: {
            avatarControlLabel("Initials", systemImage: "textformat")
        }
        .buttonStyle(.plain)
        .accessibilityLabel("Use initials")
    }

    private var defaultPhotoButton: some View {
        Button {
            draft.avatarMode = .asset
            photoError = ""
        } label: {
            avatarControlLabel("Default", systemImage: "person.crop.circle")
        }
        .buttonStyle(.plain)
        .accessibilityLabel("Use the default profile photo")
    }

    private func avatarControlLabel(_ title: String, systemImage: String) -> some View {
        Label(title, systemImage: systemImage)
            .font(LittleLemonTheme.body(13, weight: .semibold))
            .foregroundColor(LittleLemonTheme.green)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 8)
            .padding(.horizontal, 8)
            .background(Color.white)
            .clipShape(Capsule())
            .overlay(Capsule().stroke(LittleLemonTheme.green, lineWidth: 1))
    }

    private var actionBar: some View {
        VStack(spacing: 10) {
            if !statusMessage.isEmpty {
                Text(statusMessage)
                    .font(LittleLemonTheme.body(13, weight: .semibold))
                    .foregroundColor(LittleLemonTheme.green)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .accessibilityLabel(statusMessage)
            }

            Button("Log out") {
                confirmLogout = true
            }
            .buttonStyle(PrimaryButtonStyle())
            .accessibilityIdentifier("logoutButton")
            .accessibilityHint("Clears your profile and returns to onboarding")

            ViewThatFits(in: .horizontal) {
                HStack(spacing: 12) {
                    discardButton
                    saveButton
                }
                VStack(spacing: 10) {
                    saveButton
                    discardButton
                }
            }
        }
        .padding(.horizontal, 20)
        .padding(.top, 10)
        .padding(.bottom, 12)
        .background(Color.white)
    }

    private var discardButton: some View {
        Button("Discard changes") {
            draft = model.profileDraft
            showErrors = false
            statusMessage = "Changes discarded."
            photoError = ""
        }
        .buttonStyle(SecondaryButtonStyle())
        .disabled(draft == model.profileDraft)
        .opacity(draft == model.profileDraft ? 0.45 : 1)
        .accessibilityIdentifier("discardChanges")
    }

    private var saveButton: some View {
        Button("Save changes") {
            showErrors = true
            guard draft.isValid else {
                statusMessage = ""
                return
            }
            model.saveProfile(draft)
            draft = model.profileDraft
            showErrors = false
            statusMessage = "Changes saved."
        }
        .buttonStyle(PrimaryButtonStyle())
        .opacity(draft.isValid ? 1 : 0.45)
        .accessibilityIdentifier("saveChanges")
    }

    private var emailError: String? {
        guard showErrors else { return nil }
        if !FieldValidation.isNonEmpty(draft.email) {
            return "Enter your email."
        }
        if !FieldValidation.isValidEmail(draft.email) {
            return "Enter a valid email, such as ada@littlelemon.com."
        }
        return nil
    }

    private func loadPhoto(_ item: PhotosPickerItem) async {
        do {
            if let picked = try await item.loadTransferable(type: PickedImage.self) {
                let jpeg = AvatarImageStore.jpegData(from: picked.data) ?? picked.data
                await MainActor.run {
                    draft.avatarJPEG = jpeg
                    draft.avatarMode = .custom
                    photoError = ""
                    statusMessage = ""
                    pickerItem = nil
                }
            } else {
                await MainActor.run {
                    photoError = "Couldn't read that photo. Try another one."
                    pickerItem = nil
                }
            }
        } catch {
            await MainActor.run {
                photoError = "Couldn't read that photo. Try another one."
                pickerItem = nil
            }
        }
    }
}

struct ProfileView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            ProfileView()
        }
        .environmentObject(AppModel.preview)
    }
}
