# Little Lemon Capstone

App iOS em SwiftUI do restaurante Little Lemon, em Chicago. No primeiro uso a pessoa cria um perfil. Depois disso a Home mostra o cardápio, a busca e os filtros, e o Profile guarda os dados neste aparelho.

## Requisitos

- Mac com Xcode 15 ou mais novo
- Simulador ou iPhone com iOS 16 ou mais novo
- Swift 5, já definido no projeto

## Abrir e rodar

1. Se você está com o zip, descompacte `LittleLemonCapstone.zip`. A pasta na raiz do arquivo é `LittleLemonCapstone`.
2. Abra `LittleLemonCapstone.xcodeproj` com dois cliques. Não abra só a pasta dos fontes.
3. No seletor de destino, escolha um iPhone com iOS 16 ou mais novo.
4. Rode com o botão Run ou com `Cmd + R`.

O `Info.plist` é gerado na compilação (`GENERATE_INFOPLIST_FILE`). O nome abaixo do ícone é Little Lemon, a orientação é retrato e a tela de abertura usa o modelo padrão do Xcode.

## Equipe de assinatura

No **simulador**, uma conta paga não é necessária. Se aparecer o aviso de assinatura, abra o target **LittleLemonCapstone**, vá em **Signing & Capabilities**, deixe **Automatically manage signing** marcado e escolha o seu **Team**. Um Personal Team resolve.

`DEVELOPMENT_TEAM` está vazio de propósito, para o projeto abrir em qualquer Mac. Em um **iPhone físico** é obrigatório escolher o Team antes de instalar. Sem isso o Xcode não assina o app. O bundle id é `com.littlelemon.capstone`.

A permissão de fotos só entra em cena se você tocar em **Change photo** no Profile. O seletor do sistema não pede acesso à biblioteca inteira.

## O que testar

### Onboarding, só na primeira vez

Se o app já abriu neste simulador, apague-o (toque longo no ícone, Remove App) para limpar o `UserDefaults`.

A primeira tela tem três páginas e o botão **Next**:

1. **Welcome.** Marca, cidade e um resumo. Toque em **Next**.
2. **Your details.** Nome, sobrenome e email. Os três são obrigatórios e o email precisa ter o formato `ada@littlelemon.com`. Com o formulário inválido, **Next** não avança e a mensagem fica embaixo do campo. **Previous** volta.
3. **Confirm and register.** Mostra o nome e o email, um telefone opcional e quatro avisos. **Register** grava tudo e abre a Home.

Também dá para deslizar. A terceira página não fica aberta se nome, sobrenome ou email estiverem inválidos.

### Home

- **Header:** logo à esquerda e avatar à direita. O avatar abre o Profile.
- **Hero:** fundo verde `#495E57`, “Little Lemon” em amarelo, “Chicago” em branco, a descrição do restaurante, a foto e o campo **Search menu** com o botão circular amarelo. A lista filtra conforme você digita.
- **Menu breakdown:** o título **ORDER FOR DELIVERY!** e as pílulas Starters, Mains, Desserts e Drinks. Toque para filtrar. Toque outra vez na pílula selecionada para ver o cardápio completo.
- **Food menu list:** cada linha resume o prato com título, descrição em até duas linhas, preço e miniatura. Se a imagem remota falhar, aparece o desenho local da categoria.

O JSON oficial é `https://raw.githubusercontent.com/Meta-Mobile-Developer-PC/Working-With-Data-API/main/menu.json` (`title`, `price`, `description`, `image`, `category`). Sem rede, ou se a resposta vier vazia, surge um aviso e a lista local entra no lugar, para o app continuar usável. Puxe a tela para atualizar ou toque em **Try again**. Esse JSON não traz bebidas; Lemonade e Sparkling Water são itens locais para a categoria Drinks existir.

Busca e categoria valem para a sessão. Elas não são gravadas, para um novo lançamento mostrar o cardápio inteiro. O perfil, sim, fica gravado.

### Profile, gravação e logout

1. Abra o Profile pelo avatar. Nome, sobrenome, email, telefone e os quatro avisos já vêm do onboarding.
2. Mude o telefone ou um aviso e toque em **Save changes**. A faixa “Changes saved.” confirma.
3. Pare o app no Xcode e rode de novo. A Home abre direto. No Profile, a mudança continua lá.
4. Edite um campo e toque em **Discard changes**. O formulário volta ao último valor gravado, sem escrever por cima.
5. **Log out** pede confirmação, apaga os dados do perfil e volta ao onboarding. Feche e abra de novo: as três páginas aparecem vazias.
6. Em Profile, **Back** no canto superior esquerdo retorna à Home. A pilha é um `NavigationStack`, então o gesto da borda esquerda também volta.

**Change photo**, **Initials** e **Default** trocam o avatar. A escolha nova só permanece depois de **Save changes**.

## Pastas

- `LittleLemonCapstoneApp.swift` cria o `AppModel` com `@StateObject` e o entrega com `@EnvironmentObject`. `isLoggedIn` decide entre Onboarding e Home.
- `AppModel.swift` lê e grava o perfil no `UserDefaults` e baixa o cardápio com `URLSession` e `Codable`.
- `Views/` tem Onboarding, Home e Profile.
- `Components/` tem `HeaderView`, `HeroView`, `CategoryFilterView`, `MenuRowView` e os controles reutilizados.
- `Styles/LittleLemonTheme.swift` tem as cores e os botões.
- `Assets.xcassets` tem o ícone, AccentColor, logo, hero, avatar e os desenhos de reserva do cardápio.
- `Wireframe.jpg` é o wireframe anotado da Home, na raiz do projeto.
