# Entrega — Little Lemon Capstone

## Qual arquivo enviar

Envie **`LittleLemonCapstone.zip`**.

Dentro do zip, a primeira pasta é `LittleLemonCapstone/`. É essa pasta que contém `LittleLemonCapstone.xcodeproj`. Não compacte só os fontes soltos e não compacte uma pasta com outro nome por fora.

O wireframe está em **`Wireframe.jpg`**, na raiz do projeto (e portanto dentro do zip). Se o formulário tiver um segundo campo só para a imagem, envie esse JPG também. Se o formulário pedir um único arquivo, o zip já inclui o wireframe.

Como abrir: `LittleLemonCapstone.xcodeproj` no Xcode 15 ou mais novo, simulador iPhone com iOS 16 ou mais novo. O passo a passo e a observação sobre o Team de assinatura estão no `README.md`.

## Critérios

### Wireframe da Home

`Wireframe.jpg` mostra um celular com as quatro regiões anotadas: **Header**, **Hero**, **Menu breakdown** e **Food menu list**. No hero estão a descrição do restaurante e a search bar. No breakdown estão as categorias. Na lista, cada linha marca title, description, price e thumbnail.

### Onboarding no primeiro lançamento, com três páginas e Next

`isLoggedIn` começa falso, então a primeira abertura cai em `OnboardingView` e não na Home.

As páginas são distintas, num `TabView`:

1. Welcome, com a marca.
2. Formulário: first name, last name e email. Vazio não passa. O email precisa ser válido.
3. Confirmação, telefone opcional e preferências de aviso.

**Next** avança da página 1 para a 2 e da 2 para a 3. **Previous** volta. Na página 3, **Register** grava o perfil no `UserDefaults`, marca `isLoggedIn` e abre a Home. Deslizar até a página 3 com o formulário inválido devolve para a página 2.

### Home com header, hero, menu breakdown e food menu list

`HomeView` monta, de cima para baixo, `HeaderView`, `HeroView`, `CategoryFilterView` (o breakdown, com “ORDER FOR DELIVERY!”) e a lista de `MenuRowView`.

### Hero com descrição e busca

O hero usa o verde `#495E57`. “Little Lemon” é amarelo, “Chicago” é branco, e o texto descreve o restaurante de Chicago. Há uma foto do prato e um campo de texto **Search menu**, não só um ícone, com o botão circular amarelo. O texto filtra a lista na hora.

### Barra de categorias selecionável

As pílulas são Starters, Mains, Desserts e Drinks. A selecionada fica verde. Tocar de novo na mesma pílula limpa o filtro. A busca e a categoria funcionam juntas.

### Lista de comida resumida

Cada linha mostra título, descrição curta, preço e miniatura. Não abre outra tela: a linha já é o resumo. As fotos vêm de `AsyncImage`. Se a URL falhar ou não existir, entra a imagem local da categoria (`MenuStarters`, `MenuMains`, `MenuDesserts`, `MenuDrinks`).

Enquanto baixa, a seção da lista mostra “Loading the menu…”. Se a rede falhar, o aviso explica e a lista local aparece, então a Home nunca fica vazia por causa da rede. **Try again** e o gesto de puxar tentam de novo.

A URL é `https://raw.githubusercontent.com/Meta-Mobile-Developer-PC/Working-With-Data-API/main/menu.json`, decodificada com `Codable` nos campos `title`, `price`, `description`, `image` e `category`. Esse arquivo não tem drinks; Lemonade e Sparkling Water são itens locais para essa pílula ter linhas.

### Profile preenchido com o onboarding

O avatar do header é um `NavigationLink` para `ProfileView`. Nome, sobrenome, email, telefone e os quatro avisos (order statuses, password changes, special offers, newsletter) aparecem com o que foi registrado.

### Edições persistem depois de reiniciar

**Save changes** grava no `UserDefaults` pelo `AppModel`. Pare o app e rode de novo: `isLoggedIn` continua verdadeiro, a Home abre direto e o Profile mostra o valor salvo, inclusive o modo do avatar.

**Discard changes** copia de volta o rascunho gravado e não escreve o que estava pela metade.

Busca e categoria ficam só na memória. Reiniciar mostra o cardápio completo de propósito, para o teste de persistência não esconder pratos.

### Log out limpa o perfil

**Log out** confirma, apaga as chaves do perfil (nome, sobrenome, email, telefone, avisos, avatar) e põe `isLoggedIn` em falso. O app volta ao onboarding. Um novo lançamento continua no onboarding, com os campos vazios.

### Navegação em stack, com Back

A Home usa `NavigationStack`, não `NavigationView`. O Profile é empurrado por esse stack. A barra da Home fica oculta, mas o título dela é “Back”, então o botão do sistema no Profile mostra **Back** e desempilha a tela. O gesto da borda esquerda também volta.

### Outros detalhes pedidos

- Estado compartilhado: `LittleLemonCapstoneApp` cria `@StateObject private var model = AppModel()` e injeta `@EnvironmentObject`.
- Teclado: email usa `.emailAddress`, telefone usa `.phonePad`, nomes usam o tipo de conteúdo correspondente. A barra do teclado tem **Done**.
- Acessibilidade: logo, busca, categorias, linhas do cardápio, avatar e os botões de perfil têm rótulos.
- Alvo: iOS 16, Swift 5, bundle id `com.littlelemon.capstone`. Sem API exclusiva do iOS 17.
- Assets originais no catálogo: ícone 1024, AccentColor, logo, hero, avatar e fallbacks do cardápio.
